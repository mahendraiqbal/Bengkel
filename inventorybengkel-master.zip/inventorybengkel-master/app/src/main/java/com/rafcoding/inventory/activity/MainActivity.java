package com.rafcoding.inventory.activity;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.rafcoding.inventory.R;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        auth = FirebaseAuth.getInstance();

        FirebaseUser user = auth.getCurrentUser();
//jika user sudah login maka akan terarah ke dasboard
        if(user != null){
            finish();
            startActivity(new Intent(this, DashboardActivity.class));
        }

    }


    public void login (View view) //login or register
    {

        startActivity(new Intent(this, LoginActivity.class));

    }
    public void register (View view)
    {
        startActivity(new Intent(this, RegisterActivity.class));
    }
}

