package com.rafcoding.inventory.activity;

import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rafcoding.inventory.R;

public class DeleteItemsActivity extends AppCompatActivity {
    public static TextView resultDeleteView;
    private FirebaseAuth firebaseAuth;
    Button btnScan, btnDelete;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_items);
        firebaseAuth = FirebaseAuth.getInstance();

        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        resultDeleteView = findViewById(R.id.barcodedelete);
        btnScan = findViewById(R.id.buttonscandelete);
        btnDelete = findViewById(R.id.deleteItemToTheDatabasebtn);

        //scan delete
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ScanCodeDeleteActivity.class));
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem();
            }
        });

    }

    public void deleteItem() {
        String textBarcode = resultDeleteView.getText().toString();
        final FirebaseUser users = firebaseAuth.getCurrentUser();
        String finalUser = users != null ? users.getEmail() : "";
        String resultEmail = finalUser != null ? finalUser.replace(".", "") : "";
        if (!TextUtils.isEmpty(textBarcode)) {
            databaseReference.child(resultEmail).child("Items").child(textBarcode).removeValue()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(DeleteItemsActivity.this, "Item is Deleted", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(DeleteItemsActivity.this, "Item is empty", Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            Toast.makeText(DeleteItemsActivity.this, "Please scan Barcode", Toast.LENGTH_SHORT).show();
        }
    }
}
