package com.rafcoding.inventory.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.rafcoding.inventory.R;
import com.rafcoding.inventory.model.Items;

public class SearchItemActivity extends AppCompatActivity {
    public static EditText resultSearchView;
    Button searchBtn;
    RecyclerView mRecyclerview;
    DatabaseReference mDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_item);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        final FirebaseUser users = firebaseAuth.getCurrentUser();
        String finalUser = users != null ? users.getEmail() : "";
        String resultEmail = finalUser != null ? finalUser.replace(".", "") : "";
        mDatabaseReference = FirebaseDatabase.getInstance().getReference("Users").child(resultEmail).child("Items");
        resultSearchView = findViewById(R.id.searchfield);
        searchBtn = findViewById(R.id.searchbtnn);

        mRecyclerview = findViewById(R.id.recyclerViews);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        mRecyclerview.setLayoutManager(manager);
        mRecyclerview.setHasFixedSize(true);

        mRecyclerview.setLayoutManager(new LinearLayoutManager(this));

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchText = resultSearchView.getText().toString();
                firebaseSearch(searchText);
            }
        });
    }
    //mencari di firebase
    public void firebaseSearch(String txt) {
        Query query = mDatabaseReference.orderByChild("itemname").startAt(txt).endAt(txt + "\uf8ff");
        FirebaseRecyclerAdapter<Items, UsersViewHolder> adapter = new FirebaseRecyclerAdapter<Items, UsersViewHolder>
                (Items.class,
                        R.layout.list_layout,
                        UsersViewHolder.class,
                        query) {
            @Override
            protected void populateViewHolder(UsersViewHolder viewHolder, Items model, int position) {

                viewHolder.setDetails(model.getItembarcode(), model.getItemcategory(), model.getItemname(), model.getItemprice());
            }
        };
        mRecyclerview.setAdapter(adapter);
    }

    public static class UsersViewHolder extends RecyclerView.ViewHolder {
        View mView;

        public UsersViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
        }

        public void setDetails(String itemBarcode, String itemCategory, String itemName, String itemPrice) {
            TextView tvBarcode = mView.findViewById(R.id.viewitembarcode);
            TextView tvName = mView.findViewById(R.id.viewitemname);
            TextView tvCategory = mView.findViewById(R.id.viewitemcategory);
            TextView tvPrice = mView.findViewById(R.id.viewitemprice);

            tvBarcode.setText(itemBarcode);
            tvCategory.setText(itemCategory);
            tvName.setText(itemName);
            tvPrice.setText(itemPrice);
        }
    }
}
