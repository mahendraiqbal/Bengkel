package com.rafcoding.inventory.model;

public class User {
    public String deptname, email;

    public User(){

    }

    public User(String name, String email) {
        this.deptname = name;
        this.email = email;

    }
}
