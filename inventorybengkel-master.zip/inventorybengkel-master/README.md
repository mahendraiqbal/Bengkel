# Inventory-Barang
Inventory barang kujon motor klaten berbasis android dengan menggunakan firebase